using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Manager : MonoBehaviour
{
    //CSG-114 Final Project - EndorScape (Breakout Clone) - Chris Sprenger
    //Used knowledge and resources from 114, 115 (2D Game Kit), and 117 throughout this project

    private int level = 1;
    public int score = 0;
    public int lives = 3;

    public Ball Ball { get; private set; }
    public Paddle Paddle { get; private set; }
    public Brick[] Bricks { get; private set; }

    private void Awake()
    {
        //Keeps this loaded through all scenes of the game
        DontDestroyOnLoad(gameObject);

        SceneManager.sceneLoaded += OnLevelLoaded;
    }

    private void Start()
    {
        LoadLevel(5);
    }

    public void NewGame()
    {
        level = 1;
        LoadLevel(level);

        //Sets the paramaters for a new game at level 1
        score = 0;
        lives = 3;
    }

    public void LoadLevel(int level)
    {
        SceneManager.LoadScene("Level" + level);
    }

    private void OnLevelLoaded(Scene scene, LoadSceneMode mode)
    {
        Ball = FindObjectOfType<Ball>();
        Paddle = FindObjectOfType<Paddle>();
        Bricks = FindObjectsOfType<Brick>();
    }

    private void ResetLevel()
    {
        //Resets the Ball and Paddle to original positions while leaving bricks if there are remaining lives
        Ball.ResetBall();
        Paddle.ResetPaddle();
    }

    private void GameOver()
    {
        LoadLevel(4);
    }

    public void Miss()
    {
        //Calculates lives lost and Resets or Game Over depending on lives remaining
        lives--;

        if(lives > 0)
        {
            ResetLevel();
        }
        else
        {
            GameOver();
        }
    }
    public void Hit(Brick brick)
    {
        //Adds score based on bricks hit and point values
        score += brick.points;
        //Clearing the level loads the next level
        if(Cleared())
        {
            level++;
            LoadLevel(level);
        }
    }

    public int GetScore()
    {
        return score;
    }

    public int GetLives()
    {
        return lives;
    }

    private bool Cleared()
    {
        //Calculates if bricks have been cleared from the hierarchy to advance to the next level
        for(int i = 0; i < Bricks.Length; i++)
        {
            if(Bricks[i].gameObject.activeInHierarchy && !Bricks[i].unbreakable)
            {
                return false;
            }
        }
        return true;
    }

}
