using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FinalScore : MonoBehaviour
{
    //CSG-114 Final Project - EndorScape (Breakout Clone) - Chris Sprenger
    //Used knowledge and resources from 114, 115 (2D Game Kit), and 117 throughout this project

    public Manager manager;
    public Text displayScore;

    void Start()
    {
        //Displays the final score achieved
        manager = FindObjectOfType<Manager>();
        displayScore.text = "Total Score: " + manager.GetScore();
    }

}
