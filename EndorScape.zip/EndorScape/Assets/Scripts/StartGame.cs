using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartGame : MonoBehaviour
{
    //CSG-114 Final Project - EndorScape (Breakout Clone) - Chris Sprenger
    //Used knowledge and resources from 114, 115 (2D Game Kit), and 117 throughout this project

    public Manager mngr;

    public void StartGameButton()
    {
        //Used for the Start button on the Starting menu page, launches into the first level
        mngr = FindObjectOfType<Manager>();

        if (mngr != null)
        {
            mngr.NewGame();
        }
    }

    public void ExitGameButton()
    {
        //Hopefully quits out of the application
        mngr = FindObjectOfType<Manager>();
        Application.Quit();
    }

    public void RestartGameButton()
    {
        //A reset for the win and game over screens to get back to the main screen to play again or exit
        mngr = FindObjectOfType<Manager>();
        mngr.LoadLevel(5);
    }
}
