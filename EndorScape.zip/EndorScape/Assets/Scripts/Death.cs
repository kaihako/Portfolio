using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Death : MonoBehaviour
{

    //CSG-114 Final Project - EndorScape (Breakout Clone) - Chris Sprenger
    //Used knowledge and resources from 114, 115 (2D Game Kit), and 117 throughout this project

    private void OnCollisionEnter2D(Collision2D other)
    {
        //Used on bottom wall, if ball collides marks as a lost life
        if (other.gameObject.name == "Ball")
        {
            FindObjectOfType<Manager>().Miss();
        }
    }
}
