using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Paddle : MonoBehaviour
{

    //CSG-114 Final Project - EndorScape (Breakout Clone) - Chris Sprenger
    //Used knowledge and resources from 114, 115 (2D Game Kit), and 117 throughout this project

    public Rigidbody2D Rigidbody { get; private set; }
    public Vector2 Direction { get; private set; }
    public float speed = 30f;
    public float maxBounceAngle = 75f;

    private void Awake()
    {
        //Getting the Rigidbody component
        Rigidbody = GetComponent<Rigidbody2D>();
    }

    public void ResetPaddle()
    {
        //Used in Manager script to reset the paddle if life lost
        transform.position = new Vector2(0f, transform.position.y);
        Rigidbody.velocity = Vector2.zero;
    }

    void Update()
    {
        //Setting controls for the paddle, A or LeftArrow move left, D or RightArrow move right, any other key does nothing
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            Direction = Vector2.left;
        }
        else if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
        {
            Direction = Vector2.right;
        }
        else
        {
            Direction = Vector2.zero;
        }
    }

    private void FixedUpdate()
    {
        //Checks to see if a direction is being pressed, then move the paddle by direction * speed
        if (Direction != Vector2.zero)
        {
            Rigidbody.AddForce(Direction * speed);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        //Checks collision with the Ball and sets the new tragectory based on where it hits the paddle
        //Used some Googling to do this, forgot to jot down the source, and could not find it again to save my soul. What I found was the framework of how to set up the trajectory based on where the ball hits the paddle.
        Ball ball = collision.gameObject.GetComponent<Ball>();

        if (ball != null)
        {
            Vector3 paddlePosition = transform.position;
            Vector2 contactPoint = collision.GetContact(0).point;

            float offset = paddlePosition.x - contactPoint.x;
            float width = collision.otherCollider.bounds.size.x / 2;

            float currentAngle = Vector2.SignedAngle(Vector2.up, ball.Rigidbody.velocity);
            float bounceAngle = (offset / width) * maxBounceAngle;
            float newAngle = Mathf.Clamp(currentAngle + bounceAngle, -maxBounceAngle, maxBounceAngle);

            Quaternion rotation = Quaternion.AngleAxis(newAngle, Vector3.forward);
            ball.Rigidbody.velocity = rotation * Vector2.up * ball.Rigidbody.velocity.magnitude;
        }
    }
}
