using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Brick : MonoBehaviour
{

    //CSG-114 Final Project - EndorScape (Breakout Clone) - Chris Sprenger
    //Used knowledge and resources from 114, 115 (2D Game Kit), and 117 throughout this project

    public SpriteRenderer SpriteRenderer { get; private set; }
    public Color[] states;

    public int Health { get; private set; }
    public bool unbreakable;

    public int points = 100;

    private void Awake()
    {
        //Calls the sprite renderer on wake
        SpriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Start()
    {
        //If the brick is breakable, it's health is equal to it's states
        if (!unbreakable)
        {
            Health = states.Length;
            SpriteRenderer.color = states[Health - 1];
        }
    }

    private void Hit()
    {
        //Do nothing if unbreakable brick
        if (unbreakable)
        {
            return;
        }
        //Brick loses 1 health
        Health--;
        //If health is now 0, removes game object, otherwise lowers health and color by 1
        if (Health <= 0)
        {
            gameObject.SetActive(false);
        }
        else
        {
            SpriteRenderer.color = states[Health - 1];
        }

        FindObjectOfType<Manager>().Hit(this);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        //Checking collision with the ball
        if (collision.gameObject.name == "Ball")
        {
            Hit();
        }
    }

   
}
