using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Lives : MonoBehaviour
{
    //CSG-114 Final Project - EndorScape (Breakout Clone) - Chris Sprenger
    //Used knowledge and resources from 114, 115 (2D Game Kit), and 117 throughout this project

    public Manager manager;
    public Text displayLives;

    void Start()
    {
        displayLives = GetComponent<Text>();
    }

    void Update()
    {
        //Displays and updates lives in real time, UI element is in the upper right
        manager = FindObjectOfType<Manager>();
        displayLives.text = "Lives: " + manager.GetLives();
    }
}
