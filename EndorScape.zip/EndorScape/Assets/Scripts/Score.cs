using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    //CSG-114 Final Project - EndorScape (Breakout Clone) - Chris Sprenger
    //Used knowledge and resources from 114, 115 (2D Game Kit), and 117 throughout this project

    public Manager manager;
    public Text displayScore;

    void Start()
    {
        displayScore = GetComponent<Text>();
    }

    void Update()
    {
        //Displays and updates the score in real time, UI element is in the upper left of the screen
        manager = FindObjectOfType<Manager>();
        displayScore.text = "Score: " + manager.GetScore();
    }
}
