using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{

    //CSG-114 Final Project - EndorScape (Breakout Clone) - Chris Sprenger
    //Used knowledge and resources from 114, 115 (2D Game Kit), and 117 throughout this project

    public Rigidbody2D Rigidbody { get; private set; }
    public float speed = 500f;

    private void Awake()
    {
        //Getting the Rigidbody component
        Rigidbody = GetComponent<Rigidbody2D>();
    }

    private void Start()
    {
        ResetBall();
    }

    private void FixedUpdate()
    {
        Rigidbody.velocity = Rigidbody.velocity.normalized * speed;
    }

    public void ResetBall()
    {
        //Reset the ball position and invoke the random direction
        transform.position = Vector2.zero;
        Rigidbody.velocity = Vector2.zero;

        Invoke(nameof(RandomDirection), 1f);
    }

    private void RandomDirection()
    {
        //Setting the force and direction of the ball to fall at the beginning, randomly left or right and always down
        Vector2 force = Vector2.zero;
        force.x = Random.Range(-1f, 1f);
        force.y = -1f;

        Rigidbody.AddForce(force.normalized * speed);
    }
}
