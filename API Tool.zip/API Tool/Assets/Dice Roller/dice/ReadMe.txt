This pack includes:
-Model files (in .dae format)
-Blend file with die fully textured
-Blend file with die non textured
-GIMP project files (v2.10.20) for each UV map textured
-Images of UV maps with and without numbers
-Simple preview image :)

TEXTURES MADE BY ME USING TUFFY A PUBLIC DOMAIN FONT!
Sorry for reuploading had to fix a typo. The font I used is called Tuffy not Tuff.