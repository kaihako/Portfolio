using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(GameManager))]
public class GameManagerEditor : Editor
{
    public override void OnInspectorGUI()
    {
        // Draw default Inspector
        DrawDefaultInspector();

        // Get reference to the target (GameManager)
        GameManager gameManager = (GameManager)target;

        EditorGUILayout.Space();

        // Add buttons for CharacterStats actions
        EditorGUILayout.LabelField("Character Stats Controls", EditorStyles.boldLabel);
        if (GUILayout.Button("Randomize Stats"))
        {
            gameManager.RandomizeStats();
        }
        if (GUILayout.Button("Reset Stats"))
        {
            gameManager.ResetStats();
        }

        EditorGUILayout.Space();

        // Add buttons for RelationshipSystem actions
        EditorGUILayout.LabelField("Relationship Controls", EditorStyles.boldLabel);
        if (GUILayout.Button("Randomize Relationships"))
        {
            gameManager.RandomizeRelationships();
        }
        if (GUILayout.Button("Reset Relationships"))
        {
            gameManager.ResetRelationships();
        }

        EditorGUILayout.Space();

        // Add buttons for ConditionSystem actions
        EditorGUILayout.LabelField("Condition Controls", EditorStyles.boldLabel);
        if (GUILayout.Button("Randomize Conditions"))
        {
            gameManager.RandomizeConditions();
        }
        if (GUILayout.Button("Reset Conditions"))
        {
            gameManager.ResetConditions();
        }
    }
}