using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum RelationshipStatus
{
    Hate = 1,
    Hostile = 5,
    Neutral = 10,
    Respect = 15,
    Allied = 20
}

[System.Serializable]
public class Relationship
{
    public GameObject relatedObject; // GameObject representing entityB
    public RelationshipStatus status;
}

[System.Serializable]
public class EntityRelationships
{
    public GameObject primaryObject; // GameObject representing entityA
    public List<Relationship> relationships = new List<Relationship>();
}

public class RelationshipSystem : MonoBehaviour
{
    public List<EntityRelationships> relationshipTrackers = new List<EntityRelationships>(); // Editable in Unity Inspector
    public Text relationshipDisplay;

    public void ApplyRelationshipEffect(GameObject primary, GameObject related, RelationshipStatus newStatus)
    {
        foreach (var entity in relationshipTrackers)
        {
            if (entity.primaryObject == primary)
            {
                foreach (var relationship in entity.relationships)
                {
                    if (relationship.relatedObject == related)
                    {
                        relationship.status = newStatus;
                        UpdateRelationshipUI();
                        Debug.Log($"{primary.name} - {related.name} relationship updated to {newStatus}");
                        return;
                    }
                }
            }
        }
        Debug.LogWarning($"No relationship found between {primary.name} and {related.name}");
    }

    public void RandomizeRelationships()
    {
        foreach (var entity in relationshipTrackers)
        {
            foreach (var relationship in entity.relationships)
            {
                // Randomly assign a status from the enum values
                int randomValue = Random.Range(1, 21);
                if (randomValue <= 4)
                    relationship.status = RelationshipStatus.Hate;
                else if (randomValue <= 9)
                    relationship.status = RelationshipStatus.Hostile;
                else if (randomValue <= 14)
                    relationship.status = RelationshipStatus.Neutral;
                else if (randomValue <= 19)
                    relationship.status = RelationshipStatus.Respect;
                else
                    relationship.status = RelationshipStatus.Allied;

                Debug.Log($"{entity.primaryObject.name} - {relationship.relatedObject.name} randomized to {relationship.status}");
            }
        }
        UpdateRelationshipUI();
    }

    public void ResetRelationships()
    {
        foreach (var entity in relationshipTrackers)
        {
            foreach (var relationship in entity.relationships)
            {
                relationship.status = RelationshipStatus.Neutral;
            }
        }
        UpdateRelationshipUI();
    }

    public void UpdateRelationshipUI()
    {
        if (relationshipDisplay != null)
        {
            relationshipDisplay.text = "Relationships:\n";
            foreach (var entity in relationshipTrackers)
            {
                if (entity.primaryObject != null)
                {
                    relationshipDisplay.text += $"Primary: {entity.primaryObject.name}\n";
                    foreach (var relationship in entity.relationships)
                    {
                        if (relationship.relatedObject != null)
                        {
                            relationshipDisplay.text += $" - {relationship.relatedObject.name}: {relationship.status}\n";
                        }
                    }
                }
            }
        }
    }
}