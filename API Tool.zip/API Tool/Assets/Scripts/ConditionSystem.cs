using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class Condition
{
    public string conditionName;
    public bool hasCondition;
    public float severity; // Optional severity level (0-100)
    public bool affectsNPCReaction; // If NPCs react to the condition
}

[System.Serializable]
public class EntityConditions
{
    public GameObject targetObject; // GameObject to apply conditions to
    public List<Condition> conditions = new List<Condition>();
}

public class ConditionSystem : MonoBehaviour
{
    public List<EntityConditions> conditionTrackers = new List<EntityConditions>(); // Editable in Unity Inspector
    public Text conditionDisplay;

    // Function to apply condition effect based on target GameObject
    public void ApplyConditionEffect(GameObject target, string conditionName, bool hasCondition, float severity = 0)
    {
        foreach (var entity in conditionTrackers)
        {
            if (entity.targetObject == target)
            {
                foreach (var condition in entity.conditions)
                {
                    if (condition.conditionName == conditionName)
                    {
                        condition.hasCondition = hasCondition;
                        condition.severity = severity;
                        UpdateConditionUI();
                        Debug.Log($"Condition '{conditionName}' for {target.name} set to {hasCondition} with severity {severity}");
                        return;
                    }
                }
            }
        }
        Debug.LogError($"Condition '{conditionName}' not found for target {target.name}");
    }

    // Randomize conditions
    public void RandomizeConditions()
    {
        foreach (var entity in conditionTrackers)
        {
            foreach (var condition in entity.conditions)
            {
                condition.hasCondition = Random.value > 0.5f;
                condition.severity = condition.hasCondition ? Random.Range(0, 101) : 0;
            }
        }
        UpdateConditionUI();
    }

    // Reset all conditions
    public void ResetConditions()
    {
        foreach (var entity in conditionTrackers)
        {
            foreach (var condition in entity.conditions)
            {
                condition.hasCondition = false;
                condition.severity = 0;
            }
        }
        UpdateConditionUI();
    }

    // Update condition display in UI
    public void UpdateConditionUI()
    {
        if (conditionDisplay != null)
        {
            conditionDisplay.text = "Conditions:\n";
            foreach (var entity in conditionTrackers)
            {
                if (entity.targetObject != null)
                {
                    conditionDisplay.text += $"Target: {entity.targetObject.name}\n";
                    foreach (var condition in entity.conditions)
                    {
                        conditionDisplay.text += $"{condition.conditionName} - Present: {condition.hasCondition}, Severity: {condition.severity}, NPC Reaction: {condition.affectsNPCReaction}\n";
                    }
                }
            }
        }
    }
}