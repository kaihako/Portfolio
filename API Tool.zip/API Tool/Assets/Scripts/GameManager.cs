using UnityEditor;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public CharacterStats playerStats;
    public RelationshipSystem relationshipSystem;
    public ConditionSystem conditionSystem;

    private void Start()
    {
        playerStats?.UpdateStatUI();
        relationshipSystem?.UpdateRelationshipUI();
        conditionSystem?.UpdateConditionUI();
    }

    private void Update()
    {
        playerStats?.UpdateStatUI();
        relationshipSystem?.UpdateRelationshipUI();
        conditionSystem?.UpdateConditionUI();
    }

    // Inspector Buttons with Debugging and Editor Update
    [ContextMenu("Randomize Stats")]
    public void RandomizeStats()
    {
        playerStats?.RandomizeStats();
        Debug.Log("Stats randomized.");
        MarkSceneDirty();
    }

    [ContextMenu("Reset Stats")]
    public void ResetStats()
    {
        playerStats?.ResetStats();
        Debug.Log("Stats reset.");
        MarkSceneDirty();
    }

    [ContextMenu("Randomize Relationships")]
    public void RandomizeRelationships()
    {
        relationshipSystem?.RandomizeRelationships();
        Debug.Log("Relationships randomized.");
        MarkSceneDirty();
    }

    [ContextMenu("Reset Relationships")]
    public void ResetRelationships()
    {
        relationshipSystem?.ResetRelationships();
        Debug.Log("Relationships reset.");
        MarkSceneDirty();
    }

    [ContextMenu("Randomize Conditions")]
    public void RandomizeConditions()
    {
        conditionSystem?.RandomizeConditions();
        Debug.Log("Conditions randomized.");
        MarkSceneDirty();
    }

    [ContextMenu("Reset Conditions")]
    public void ResetConditions()
    {
        conditionSystem?.ResetConditions();
        Debug.Log("Conditions reset.");
        MarkSceneDirty();
    }

    // Mark the scene as dirty to force an update
    private void MarkSceneDirty()
    {
#if UNITY_EDITOR
        EditorUtility.SetDirty(this);
#endif
    }
}
