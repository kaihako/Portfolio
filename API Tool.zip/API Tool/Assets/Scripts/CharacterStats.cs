using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class Stat
{
    public string statName;
    public float statValue;
}

public class CharacterStats : MonoBehaviour
{
    public List<Stat> stats = new List<Stat>(); // Editable in Unity Inspector
    public Text statDisplay;

    // Function to get a stat by name
    public float GetStat(string statName)
    {
        foreach (Stat stat in stats)
        {
            if (stat.statName == statName)
                return stat.statValue;
        }
        Debug.LogError($"Stat {statName} does not exist.");
        return 0;
    }

    // Function to apply effects based on stats (attach to any object needing this)
    public void ApplyStatEffect(string statName, float value)
    {
        for (int i = 0; i < stats.Count; i++)
        {
            if (stats[i].statName == statName)
            {
                stats[i].statValue += value;
                UpdateStatUI();
                Debug.Log($"{statName} changed by {value}. New value: {stats[i].statValue}");
                return;
            }
        }
        Debug.LogWarning($"Stat {statName} does not exist to apply effect.");
    }

    public void RandomizeStats()
    {
        foreach (Stat stat in stats)
        {
            stat.statValue = Random.Range(0, 21);
        }
        UpdateStatUI();
        Debug.Log("Randomized stats.");
    }

    public void ResetStats()
    {
        foreach (Stat stat in stats)
        {
            stat.statValue = 0;
        }
        UpdateStatUI();
        Debug.Log("Stats reset.");
    }

    // Function to update UI display
    public void UpdateStatUI()
    {
        if (statDisplay != null)
        {
            statDisplay.text = "Stats:\n";
            foreach (Stat stat in stats)
            {
                statDisplay.text += $"{stat.statName}: {stat.statValue}\n";
            }
        }
    }
}
