using UnityEngine;

public class Spike : EnemyDamage
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        base.OnTriggerEnter2D(collision);
    }
}