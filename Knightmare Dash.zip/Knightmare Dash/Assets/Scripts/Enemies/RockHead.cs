using UnityEngine;
using System.Collections;

public class RockHead : EnemyDamage
{
    [Header("RockHead Settings")]
    [SerializeField] private float dropSpeed;
    [SerializeField] private float returnSpeed;
    [SerializeField] private float range;
    [SerializeField] private float delay;
    [SerializeField] private LayerMask groundLayer;
    private Vector3 originalPosition;
    private Coroutine movementCoroutine;

    [Header("Sounds")]
    [SerializeField] private AudioClip impactSound;

    private void OnEnable()
    {
        originalPosition = transform.position;
        StartMovement();
    }

    private void StartMovement()
    {
        if (movementCoroutine != null)
        {
            StopCoroutine(movementCoroutine);
        }
        movementCoroutine = StartCoroutine(MoveRockHead());
    }

    private IEnumerator MoveRockHead()
    {
        while (true)
        {
            Vector3 targetPosition = originalPosition + Vector3.down * range;
            yield return MoveToPosition(targetPosition, dropSpeed);
            yield return new WaitForSeconds(delay);
            yield return MoveToPosition(originalPosition, returnSpeed);
            yield return new WaitForSeconds(delay);
        }
    }

    private IEnumerator MoveToPosition(Vector3 targetPosition, float speed)
    {
        while (Vector3.Distance(transform.position, targetPosition) > 0.1f)
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPosition, speed * Time.deltaTime);
            yield return null;

            RaycastHit2D hit = Physics2D.Raycast(transform.position, (targetPosition - transform.position).normalized, 0.1f, groundLayer);
            if (hit.collider != null)
            {
                transform.position = targetPosition;
                yield break;
            }
        }
        transform.position = targetPosition;
    }

    private void StopMovement()
    {
        if (movementCoroutine != null)
        {
            StopCoroutine(movementCoroutine);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        SoundManager.instance.PlaySound(impactSound);
        base.OnTriggerEnter2D(collision);
        if (((1 << collision.gameObject.layer) & groundLayer) != 0)
        {
            StopMovement();
        }
    }
}