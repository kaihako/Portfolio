using UnityEngine;

public class SawTrap : EnemyDamage
{
    [Header("SawTrap Settings")]
    [SerializeField] private float movementDistance;
    [SerializeField] private float speed;
    [SerializeField] private bool verticalMovement;
    [SerializeField] private bool startMovingLeftOrDown;
    private bool isMoving;
    private bool movingLeftOrDown;
    private float minEdge;
    private float maxEdge;

    [Header("Player Detection Settings")]
    [SerializeField] private float detectionRadius;
    [SerializeField] private LayerMask playerLayer;
    [SerializeField] private bool requiresPlayerDetection;

    [Header("Sounds")]
    [SerializeField] private AudioClip sawSound;

    private void Awake()
    {
        if (verticalMovement)
        {
            minEdge = transform.position.y - movementDistance;
            maxEdge = transform.position.y + movementDistance;
        }
        else
        {
            minEdge = transform.position.x - movementDistance;
            maxEdge = transform.position.x + movementDistance;
        }

        movingLeftOrDown = startMovingLeftOrDown;
    }

    private void Update()
    {
        if (requiresPlayerDetection)
        {
            DetectPlayer();
        }
        else
        {
            if (!isMoving)
            {
                isMoving = true;
            }
            MoveSawTrap();
        }
    }

    private void DetectPlayer()
    {
        Collider2D[] playersInRange = Physics2D.OverlapCircleAll(transform.position, detectionRadius, playerLayer);
        if (playersInRange.Length > 0 && !isMoving)
        {
            isMoving = true;
        }

        if (isMoving)
        {
            MoveSawTrap();
        }
    }

    private void MoveSawTrap()
    {
        if (!SoundManager.instance.IsPlaying(sawSound))
        {
            SoundManager.instance.PlayLoopingSound(sawSound);
        }

        bool moved = false;

        if (verticalMovement)
        {
            if (movingLeftOrDown)
            {
                if (transform.position.y > minEdge)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y - speed * Time.deltaTime, transform.position.z);
                    moved = true;
                }
                else
                {
                    movingLeftOrDown = false;
                }
            }
            else
            {
                if (transform.position.y < maxEdge)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y + speed * Time.deltaTime, transform.position.z);
                    moved = true;
                }
                else
                {
                    movingLeftOrDown = true;
                }
            }
        }
        else
        {
            if (movingLeftOrDown)
            {
                if (transform.position.x > minEdge)
                {
                    transform.position = new Vector3(transform.position.x - speed * Time.deltaTime, transform.position.y, transform.position.z);
                    moved = true;
                }
                else
                {
                    movingLeftOrDown = false;
                }
            }
            else
            {
                if (transform.position.x < maxEdge)
                {
                    transform.position = new Vector3(transform.position.x + speed * Time.deltaTime, transform.position.y, transform.position.z);
                    moved = true;
                }
                else
                {
                    movingLeftOrDown = true;
                }
            }
        }

        if (!moved)
        {
            SoundManager.instance.StopLoopingSound();
        }
    }

    private void OnDisable()
    {
        SoundManager.instance.StopLoopingSound();
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        if (verticalMovement)
        {
            Gizmos.DrawWireSphere(transform.position, detectionRadius);
            Gizmos.DrawLine(new Vector3(transform.position.x, minEdge, transform.position.z), new Vector3(transform.position.x, maxEdge, transform.position.z));
        }
        else
        {
            Gizmos.DrawWireSphere(transform.position, detectionRadius);
            Gizmos.DrawLine(new Vector3(minEdge, transform.position.y, transform.position.z), new Vector3(maxEdge, transform.position.y, transform.position.z));
        }
    }
}