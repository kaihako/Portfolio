using UnityEngine;

public class ArrowTrap : MonoBehaviour
{
    [Header("ArrowTrap Settings")]
    [SerializeField] private float attackCooldown;
    [SerializeField] private Transform firePoint;
    [SerializeField] private GameObject[] arrows;
    private float cooldownTimer;

    [Header("Player Detection Settings")]
    [SerializeField] private bool requiresPlayerDetection;
    [SerializeField] private float detectionRange;
    [SerializeField] private LayerMask playerLayer;
    private bool playerDetected;

    [Header("Sounds")]
    [SerializeField] private AudioClip arrowSound;

    private void Update()
    {
        cooldownTimer += Time.deltaTime;

        if (requiresPlayerDetection)
        {
            playerDetected = DetectPlayer();
            if (playerDetected && cooldownTimer >= attackCooldown)
            {
                Attack();
            }
        }
        else
        {
            if (cooldownTimer >= attackCooldown)
            {
                Attack();
            }
        }
    }

    private bool DetectPlayer()
    {
        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.left, detectionRange, playerLayer);
        return hit.collider != null;
    }

    private void Attack()
    {
        cooldownTimer = 0;

        SoundManager.instance.PlaySound(arrowSound);
        int arrowIndex = FindArrows();
        if (arrowIndex != -1)
        {
            arrows[arrowIndex].transform.position = firePoint.position;
            arrows[arrowIndex].GetComponent<EnemyProjectile>().ActivateProjectile();
        }
    }

    private int FindArrows()
    {
        for (int i = 0; i < arrows.Length; i++)
        {
            if (!arrows[i].activeInHierarchy)
                return i;
        }
        return -1; // Return -1 if no inactive arrows are found
    }

    public void DeactivateAllArrows()
    {
        for (int i = 0; i < arrows.Length; i++)
        {
            if (arrows[i].activeInHierarchy)
            {
                EnemyProjectile projectile = arrows[i].GetComponent<EnemyProjectile>();
                if (projectile != null)
                {
                    projectile.StopAndResetProjectile();
                }
            }
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawLine(transform.position, transform.position + Vector3.left * detectionRange);
    }
}