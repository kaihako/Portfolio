using UnityEngine;

public class EnemyProjectile : EnemyDamage
{
    [Header("Components")]
    [SerializeField] private float speed;
    [SerializeField] private float resetTime;
    private float lifetime;
    private bool isActive;

    public void ActivateProjectile()
    {
        lifetime = 0;
        isActive = true;
        gameObject.SetActive(true);
    }

    private void Update()
    {
        if (!isActive) return;

        float movementSpeed = speed * Time.deltaTime;
        transform.Translate(movementSpeed, 0, 0);

        lifetime += Time.deltaTime;
        if (lifetime > resetTime)
            DeactivateProjectile();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        base.OnTriggerEnter2D(collision);
        DeactivateProjectile();
    }

    public void DeactivateProjectile()
    {
        isActive = false;
        gameObject.SetActive(false);
    }

    public void StopAndResetProjectile()
    {
        DeactivateProjectile();
    }
}