using System.Collections;
using UnityEngine;

public class FireTrap : MonoBehaviour
{
    [Header("FireTrap Settings")]
    [SerializeField] private float damage;
    [SerializeField] private float activationDelay;
    [SerializeField] private float activeTime;
    private bool triggered;
    private bool active;

    [Header("Components")]
    private Animator anim;
    private SpriteRenderer spriteRend;
    private Health playerHealth;

    [Header("Sounds")]
    [SerializeField] private AudioClip fireSound;

    private void Awake()
    {
        anim = GetComponent<Animator>();
        spriteRend = GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        if (playerHealth != null && active)
            playerHealth.TakeDamage(damage);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            playerHealth = collision.GetComponent<Health>();

            if (!triggered)
                StartCoroutine(ActivateFireTrap());

            if (active)
                collision.GetComponent<Health>().TakeDamage(damage);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player")
            playerHealth = null;
    }

    private IEnumerator ActivateFireTrap()
    {
        //Turn sprite red to notify player and trigger trap
        triggered = true;
        spriteRend.color = Color.red;

        //Wait for delay, activate trap, trigger animation, and return color to normal
        yield return new WaitForSeconds(activationDelay);
        SoundManager.instance.PlaySound(fireSound);
        spriteRend.color = Color.white;
        active = true;
        anim.SetBool("Activated", true);

        //Wait for delay, deactivate trap, and reset
        yield return new WaitForSeconds(activeTime);
        active = false;
        triggered = false;
        anim.SetBool("Activated", false);
    }
}