using UnityEngine;
using System.Collections;

public class SpikeTrap : MonoBehaviour
{
    [Header("SpikeTrap Settings")]
    [SerializeField] private Transform[] spikePieces;
    [SerializeField] private float shootSpeed;
    [SerializeField] private LayerMask playerLayer;
    [SerializeField] private LayerMask collisionLayers;
    private bool hasShot = false;

    [Header("Player Detection Settings")]
    [SerializeField] private float detectionRadius;
    [SerializeField] private bool requiresPlayerDetection;
    private bool playerDetected;

    [Header("Sounds")]
    [SerializeField] private AudioClip spikeSound;

    private void Update()
    {
        if (requiresPlayerDetection && !hasShot)
        {
            playerDetected = DetectPlayer();
            if (playerDetected)
            {
                ShootSpike();
            }
        }
    }

    private bool DetectPlayer()
    {
        Collider2D hit = Physics2D.OverlapCircle(transform.position, detectionRadius, playerLayer);
        return hit != null;
    }

    private void ShootSpike()
    {
        if (hasShot) return;

        int randomIndex = Random.Range(0, spikePieces.Length);
        Transform chosenSpike = spikePieces[randomIndex];
        hasShot = true;
        StartCoroutine(ShootSpikeRoutine(chosenSpike));
    }

    private IEnumerator ShootSpikeRoutine(Transform spike)
    {
        Vector3 originalPosition = spike.position;
        Vector3 direction = Vector3.up;
        SoundManager.instance.PlaySound(spikeSound);
        while (true)
        {
            float movementSpeed = shootSpeed * Time.deltaTime;
            spike.position += direction * movementSpeed;

            RaycastHit2D hit = Physics2D.Raycast(spike.position, direction, movementSpeed, collisionLayers);
            if (hit.collider != null)
            {
                spike.gameObject.SetActive(false);
                yield break;
            }

            yield return null;
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
    }
}