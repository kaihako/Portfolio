using UnityEngine;

public class RoomManager : MonoBehaviour
{
    public static RoomManager Instance { get; private set; }
    public Transform CurrentRoom { get; private set; }
    public Transform PreviousRoom { get; private set; }
    public Transform RoomWherePlayerDied { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else if (Instance != this)
        {
            Destroy(gameObject);
        }
    }

    public void SetActiveRoom(Transform newRoom)
    {
        if (CurrentRoom != null)
        {
            SetRoomActive(CurrentRoom, false);
        }

        PreviousRoom = CurrentRoom;
        CurrentRoom = newRoom;
        SetRoomActive(CurrentRoom, true);
    }

    private void SetRoomActive(Transform room, bool isActive)
    {
        if (room == null)
        {
            return;
        }

        foreach (Transform child in room)
        {
            if (child.CompareTag("Enemy"))
            {
                child.gameObject.SetActive(isActive);
            }
        }
    }

    public void UpdateRoom(Transform newRoom)
    {
        PreviousRoom = CurrentRoom;
        CurrentRoom = newRoom;
    }

    public void SetRoomWherePlayerDied(Transform room)
    {
        RoomWherePlayerDied = room;
    }
}