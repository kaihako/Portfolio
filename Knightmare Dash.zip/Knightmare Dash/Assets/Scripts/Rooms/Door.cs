using UnityEngine;

public class Door : MonoBehaviour
{
    [SerializeField] private Transform previousRoom;
    [SerializeField] private Transform nextRoom;
    [SerializeField] private CameraController cam;

    private bool playerInTransitionZone = false;

    private void Awake()
    {
        cam = Camera.main.GetComponent<CameraController>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            playerInTransitionZone = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player") && playerInTransitionZone)
        {
            bool movingRight = collision.transform.position.x < transform.position.x;
            bool movingUp = collision.transform.position.y > transform.position.y;

            if (Mathf.Abs(collision.transform.position.x - transform.position.x) > Mathf.Abs(collision.transform.position.y - transform.position.y))
            {
                HandleRoomChange(movingRight);
            }
            else
            {
                HandleRoomChange(!movingUp);
            }

            playerInTransitionZone = false;
        }
    }

    private void HandleRoomChange(bool movingRight)
    {
        Transform roomToActivate = movingRight ? previousRoom: nextRoom;
        Transform roomToDeactivate = movingRight ? nextRoom : previousRoom;

        RoomManager.Instance.UpdateRoom(roomToActivate);
        cam.MoveToNewRoom(roomToActivate);
        ActivateRoom(roomToActivate, roomToDeactivate);
    }

    public void ActivateRoom(Transform roomToActivate, Transform roomToDeactivate)
    {
        if (roomToDeactivate != null)
        {
            Room roomScript = roomToDeactivate.GetComponent<Room>();
            if (roomScript != null)
            {
                roomScript.ActivateRoom(false);
            }
        }

        if (roomToActivate != null)
        {
            Room roomScript = roomToActivate.GetComponent<Room>();
            if (roomScript != null)
            {
                roomScript.ActivateRoom(true);
            }
        }
    }

    public void SetRoomActive(Transform room, bool isActive)
    {
        foreach (Transform child in room)
        {
            if (child.CompareTag("Enemy"))
            {
                child.gameObject.SetActive(isActive);
            }
        }
    }
}