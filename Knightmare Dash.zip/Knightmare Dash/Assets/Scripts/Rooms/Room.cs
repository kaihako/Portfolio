using UnityEngine;

public class Room : MonoBehaviour
{
    [SerializeField] private GameObject[] enemies;
    private Vector3[] initialPosition;

    private void Awake()
    {
        initialPosition = new Vector3[enemies.Length];
        for (int i = 0; i < enemies.Length; i++)
        {
            if (enemies[i] != null)
            {
                initialPosition[i] = enemies[i].transform.position;
                enemies[i].SetActive(false);
            }
        }
    }

    public void ActivateRoom(bool _status)
    {
        for (int i = 0; i < enemies.Length; i++)
        {
            if (enemies[i] != null)
            {
                enemies[i].SetActive(_status);
                if (_status)
                {
                    enemies[i].transform.position = initialPosition[i];
                }
                else
                {
                    ArrowTrap arrowTrap = enemies[i].GetComponent<ArrowTrap>();
                    if (arrowTrap != null)
                    {
                        arrowTrap.DeactivateAllArrows();
                    }
                }
            }
        }
    }
}