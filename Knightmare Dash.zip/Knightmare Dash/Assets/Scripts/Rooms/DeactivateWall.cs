using UnityEngine;

public class DeactivateWall : MonoBehaviour
{
    [SerializeField] private GameObject fakeWall;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            if (fakeWall != null)
            {
                fakeWall.SetActive(false);
            }
        }
    }
}