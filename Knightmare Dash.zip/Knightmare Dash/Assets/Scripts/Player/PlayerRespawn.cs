using UnityEngine;

public class PlayerRespawn : MonoBehaviour
{
    [SerializeField] private AudioClip checkpointSound;
    private Transform currentCheckpoint;
    private Health playerHealth;
    private UIManager uiManager;
    private bool respawnedAfterDeath;

    private void Awake()
    {
        playerHealth = GetComponent<Health>();
        uiManager = FindObjectOfType<UIManager>();
    }

    private void Start()
    {
        respawnedAfterDeath = false;
    }

    public void RespawnCheck()
    {
        if (currentCheckpoint == null)
        {
            if (respawnedAfterDeath)
            {
                uiManager.GameOver();
            }
            return;
        }

        playerHealth.Respawn();
        transform.position = currentCheckpoint.position;

        // Move the camera to the checkpoint's room
        //Camera.main.GetComponent<CameraController>().MoveToNewRoom(currentCheckpoint.parent);

        respawnedAfterDeath = true;

        DeactivateCheckpoint();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Checkpoint") || collision.CompareTag("DeactivateWall"))
        {
            if (currentCheckpoint != null)
            {
                DeactivateCheckpoint();
            }

            currentCheckpoint = collision.transform;
            SoundManager.instance.PlaySound(checkpointSound);
            collision.GetComponent<Collider2D>().enabled = false;
            collision.GetComponent<Animator>().SetTrigger("Appear");
            respawnedAfterDeath = false;
        }
    }

    private void DeactivateCheckpoint()
    {
        if (currentCheckpoint != null)
        {
            currentCheckpoint.GetComponent<Collider2D>().enabled = false;
            currentCheckpoint = null;
        }
    }
}